## Master results
`Results_master.xlsx` contains processed data from all the different experiments. The first tab contains the average fetch sequence over all 100 runs per configuration, the second tab additional information and the last tab contains all data used for graphs in the paper.

## Raw Data
`x_x_x.csv` are files that were directly produced by our experiments. The first x denotes the size of the warehouse (5x5, 8x8, 11x11 grids), the second x denotes the number of agents (0,1,2,4), and the last x denotes the mode where 0 is a posteriori, 1 is a priori, and 2 is maze.
